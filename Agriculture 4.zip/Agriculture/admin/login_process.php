<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: Arial, sans-serif;
    }

    .container {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        background-color: #f5f5f5;
    }

    .login-container {
        background-color: #fff;
        padding: 40px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 400px;
        max-width: 90%;
    }

    .login-title {
        font-size: 30px;
        font-weight: 600;
        margin-bottom: 30px;
        text-align: center;
        color: #333;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-control {
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 14px;
        width: 100%;
        font-size: 16px;
        transition: border-color 0.3s ease;
    }

    .form-control:focus {
        border-color: #5d6ec6;
        outline: none;
    }

    .btn-login {
        background-color: #5d6ec6;
        color: white;
        font-weight: 600;
        border: none;
        border-radius: 4px;
        padding: 14px 20px;
        font-size: 18px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        width: 100%;
    }

    .btn-login:hover {
        background-color: #4455b8;
    }

    .btn-back {
        color: #5d6ec6;
        font-weight: 600;
        text-decoration: none;
        display: block;
        text-align: center;
        margin-top: 20px;
        transition: color 0.3s ease;
    }

    .btn-back:hover {
        color: #4455b8;
    }
</style>


<?php echo " 
    <div class='container'>
    
    <div class='login-container'>
        <div class='login-title'>Official Login</div>
        <form method='POST'>
            <div class='form-group'>
                <label for='user'>User Id</label>
                <input type='text' id='user' name='user' class='form-control' placeholder='User Id'>
            </div>
            <div class='form-group'>
                <label for='pass'>Password</label>
                <input type='password' id='pass' name='pass' class='form-control' placeholder='Password'>
            </div>
            <button type='submit' id='log' name='log' class='btn btn-login'>Login</button>
        </form>
        <a href='../' class='btn-back'>Back to Farmer Portal</a>
    </div>
</div>

</div>";
