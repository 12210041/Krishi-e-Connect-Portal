<?php
include 'officialHeader.php';
?>
<style>
  .fdetails{
    margin-left:14%;
  }
    table{
      width:98%;
        border:1px solid green;
        border-collapse: collapse;
        font-size:99px;
    }
    th{
        background:lightblue;
        color:red;
        font-weight:600;
        border:1px solid green;
        text-align:center;
        font-size:20px;
    }
    td{
        text-align:center;
    }
        ::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background: #888;
}

::-webkit-scrollbar-thumb:hover {
  background: #555;
}
table img:hover{
   transform:translateX(30%) scale(1.1);
   transition:.5s;
   border-radius:20px;
   
}
@media (max-width:800px) {
  .fdetails{
    margin:0;
    font-size:10px;
  }
  th,td{
       
        font-weight:400;
        font-size:10px;
    }

}
    </style>
<?php
$page=($_GET['page']-1)*5;
if($area=='india'){
  $sql="select * from farmer_reg LIMIT 5 OFFSET $page";
}else
{
  $sql="select * from farmer_reg where block='$area' or dist='$area' or state='$area'";
}
if(isset($_GET['reg'])){
  $sql="select * from farmer_reg where concat(state,farmerid)='$_GET[reg]' or f_name=''";}
$res=mysqli_query($conn,$sql);
echo "
<div class=fdetails>
<form class=form-inline my-2 my-lg-0 action=farmer_get_details.php method=get>
<input class=form-control mr-sm-2 type=search placeholder=Search aria-label=Search p-2 name=reg>
<button class=btn btn-outline-success my-2 my-sm-0 type=submit>Search</button>
<a href=farmer_get_details.php?page=1 class=w3-bar-item w3-button>View All</a>
</form>
<table width=100%>
<tr>
<th>
photo
</th>
<th>
Registration Number
</th>
<th>
Name
</th><th>Dist</th><th>Block</th><th>Mobile</th>
</tr>
";

while($row=mysqli_fetch_assoc($res))

{
    echo "<tr>
    <td><img src='$row[photo]' width='100px'></td>
    <td>$row[state]$row[farmerid]</td>
    <td>$row[f_name] $row[l_name]</td>
    <td>$row[dist]</td>
    <td>$row[block]</td>
    <td>$row[mob]</td>
    </tr>";
}
$no_p=$n/5;
echo "
</table>
<nav aria-label=Page navigation example float-right>
  <ul class=pagination justify-content center>
    <li class=page-item>
      <a class=page-link href=# aria-label=Previous>
        <span aria-hidden=true>&laquo;</span>
        <span class=sr-only>Previous</span>
      </a>
    </li>
    ";
    for($i=1;$i<=$no_p+1;$i++){
      echo "<li class=page-item><a class=page-link href=farmer_get_details.php?page=$i>$i</a></li>";
    }
    echo "
    <li class=page-item>
      <a class=page-link href=# aria-label=Next>
        <span aria-hidden=true>&raquo;</span>
        <span class=sr-only>Next</span>
      </a>
    </li>
  </ul>
</nav>
</div>
";

?>