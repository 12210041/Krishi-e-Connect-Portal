<style>
    
</style>
<?php
include '../includes/dbConnection.php';
$sql="select * from diesel";
$sql1="select * from diesel where status='Rejected'";
$sql2="select * from diesel where status='Approved'";
$query=mysqli_query($conn,$sql);
$count=mysqli_num_rows($query);
$query1=mysqli_query($conn,$sql1);
$count1=mysqli_num_rows($query1);
$query2=mysqli_query($conn,$sql2);
$count2=mysqli_num_rows($query2);
$pending=$count-($count1+$count2);
echo "

    <p>डीजल अनुदान</p>
    <p>Application Recieved: <span>$count</span></p>
    <p style='color:green'>Approved <span>: </span>$count2</p>
    <p>Pending <span>: </span>$pending</p>
    <p style='color:red'>Rejected <span>: </span>$count1</p>

";

?>