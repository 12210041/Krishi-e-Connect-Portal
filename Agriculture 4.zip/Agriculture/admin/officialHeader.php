<?php
session_start();
include '../includes/dbConnection.php';
include 'verifylogin.php';
$d=$_SESSION['officialusr'];
$sql="select * from Department where mob='$d';";
$res=mysqli_query($conn,$sql);
$data=mysqli_fetch_assoc($res);
$area=$data['area'];
if($area=='india'){
  $sql="select * from farmer_reg";
}else
{
  $sql="select * from farmer_reg where block='$area' or dist='$area' or state='$area'";
}
$res=mysqli_query($conn,$sql);
$n=mysqli_num_rows($res);
?>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="/Agriculture/css/style.css">
  <link rel="stylesheet" href="/Agriculture/css/index.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    /* Sidebar styles */
    .sidebar {
      height: 100%;
      width: 250px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0px; /* Initially hide the sidebar */
      background-color: #007bff;
      overflow-x: hidden;
      padding-top: 20px;
      transition: left 0.3s;
    }

    .sidebar h3 {
      text-align: center;
      color: #fff;
    }

    .sidebar a {
      padding: 10px;
      text-decoration: none;
      font-size: 18px;
      color: #fff;
      display: flex;
      align-items: center;
      transition: 0.3s;
    }

    .sidebar a:hover {
      background-color: #0056b3;
    }

    .sidebar a i {
      margin-right: 10px;
    }

    /* Page content styles */
    .content {
      /* margin-left: 250px; */
      width:100%;
      margin:0;
      top:0;
    }

    .header {
      background-color: #007bff;
      
      padding: 20px;
      text-align: center;
      /* margin-bottom: 20px; */
    }

    .header h1 {
      color: white;
      margin: 0;
      font-size: 24px;
    }
    @media (max-width: 800px) {
      .sidebar {
        left: -250px; /* Show the sidebar */
      }
    }
    #menuBtn{
      position: inherit;
      left:250px;
      top:0px;
    }
  </style>
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">

</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
<button class="btn btn-warning" id="menuBtn">Menu</button>
  <h3><span class="material-icons">menu</span> Menu</h3>
  <a href="Home.php"><span class="material-icons">home</span> Home</a>
  <a href="farmer_get_details.php?page=1"><span class="material-icons">people</span> View Farmer</a>
  <a href="DiesalSubsidy.php"><span class="material-icons">attach_money</span> Diesal Subsidy</a>
  <a href="createannouncement.php"><span class="material-icons">message</span> Send Message</a>
  <a href="logout.php"><span class="material-icons">exit_to_app</span> Logout</a>
</div>

<!-- Page Content -->
<div class="content">
  <div class="header">
    <h1>Welcome to Official Portal of <?php echo $data['Role'].'('.$data['Name'].')';?></h1>
  </div>

  <!-- Your page content goes here -->

</div>

<script>
  document.querySelector("#menuBtn").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    if (sidebar.style.left === "0px") {
      sidebar.style.left = "-250px"; 
    } else {
      sidebar.style.left = "0px";
    }
  });
</script>
<script src="../JS/jquery.js"></script>
<script>
    $(document).ready(function() {
        
    });
</script>
 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>  
</body>