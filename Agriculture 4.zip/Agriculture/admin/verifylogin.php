<?php
session_start();
if(!isset($_SESSION['officialusr']))
{
header("location:login.php");
}
?>