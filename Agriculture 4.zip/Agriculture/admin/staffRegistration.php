<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stylish Form</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        position: absolute;
        width: 30%;
        left:47%;
        background-color: #fff;
        padding: 10px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }
    .form-group input, .form-group select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .form-group button {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
    }
    .message {
        margin-top: 10px;
        padding: 10px;
        border-radius: 5px;
    }
    .error {
        background-color: #f44336;
        color: white;
    }
    .success {
        background-color: #4CAF50;
        color: white;
    }
</style>
</head>
<body>
    <?php
    include 'admindashboard.php';
    ?>
<div class="container">
    <h2>Registration Form</h2>
    <form  method="post" >
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="mobile">Mobile:</label>
            <input type="text" id="mobile" name="mobile" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="role">Role:</label>
            <select id="role" name="role">
                <option value="admin">Admin</option>
                <option value="BO">BO</option>
                <option value="CO">CO</option>
                <option value="DM">DM</option>
                <option value="CAO">Chief Agriculture Officer(CAO)</option>
                <option value="Heade Of Agriculture Department">Heade Of Agriculture Department</option>
            </select>
        </div>
        <div class="form-group">
            <label for="area">Area:</label>
            <input type="text" id="area" name="area" required>
        </div>
        <div class="form-group">
            <label for="office">Office:</label>
            <input type="text" id="office" name="office" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <button type="submit" name="submit">Register</button>
        </div>
    </form>
    <?php
include '../includes/dbConnection.php';

if(isset($_POST['submit'])){
   
    $area=$_POST['area'];
    $role=$_POST['role'];
    $name=$_POST['name'];
    $office=$_POST['office'];
    $password=$_POST['password'];
    $mob=$_POST['mobile'];
    // SQL query to insert data into the Department table
    $sql = "INSERT INTO Department (area, Role, Name, Office, password, mob) 
            VALUES ('$area', '$role', '$name', '$office', '$password',$mob);";

    if(mysqli_query($conn, $sql)){
        
        echo '<div class="message success">Staff registration Success</div>';
    } else {
        print_r($_POST);
        echo '<div class="message error">Something went wrong: ' . mysqli_error($conn) . '</div>';
    }
}
?>

</div>
</body>
</html>
