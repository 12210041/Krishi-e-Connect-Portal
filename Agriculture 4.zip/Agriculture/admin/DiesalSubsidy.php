<?php
include 'officialHeader.php';

?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        
    }
    table {
        width: 80%;
        margin-left:15%;
        border-collapse: collapse;
    }
    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    .view-button {
        background-color: #4CAF50;
        color: white;
        padding: 8px 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-button:hover {
        background-color: #45a049;
    }
    @media (max-width:800px) {
        table {
        width: 90%;
        margin-left:0%;
        border-collapse: collapse;
    } 
    th, td{
        font-size:10px;
        padding:5px;
    } 
    }
</style>
</head>
<body>
    <center><h1>Application List</h1></center>
    <hr> <hr> <hr>
<table>
    <thead>
        <tr>
            <th>Application No</th>
            <th>Farmer's Registration</th>
            <th>Scheme Name</th>
            <th>Scheme Type</th>
            <th>Application Date</th>
            <th>Status</th>
            <th>View Details</th>
        </tr>
    </thead>
    <tbody>
        <!-- Example Row 1 -->
        <?php
        if($data['Role']=='Heade Of Agriculture Department'){
            $qs="select * from Diesal INNER JOIN Schemes on Diesal.Scheme_id=Schemes.Scheme_id INNER JOIN farmer_reg on Diesal.Farmerid=concat(farmer_reg.state,farmer_reg.farmerid) where Scheme_Type='central' or
            farmer_reg.state='$data[area]' or farmer_reg.dist='$data[area]' or farmer_reg.block='$data[area]'";
        }else
        {
            $qs="select * from Diesal INNER JOIN Schemes on Diesal.Scheme_id=Schemes.Scheme_id INNER JOIN farmer_reg on Diesal.Farmerid=concat(farmer_reg.state,farmer_reg.farmerid) where 
        farmer_reg.state='$data[area]' or farmer_reg.dist='$data[area]' or farmer_reg.block='$data[area]'";
        }
        
        $resp=mysqli_query($conn,$qs);
        while($dt=mysqli_fetch_assoc($resp)){
            echo "
            <tr>
            <td>$dt[App_id]</td>
            <td>$dt[state]$dt[farmerid]</td>
            <td>$dt[Scheme_Name]</td>
            <td>$dt[Scheme_Type]</td>
            <td>$dt[App_date]</td>
            <td>status</td>
            <td><button class='view-button' onclick='openView($dt[App_id],$data[d_id])'>View App</button></td>
        </tr>
            ";
        }
        ?>
        

        <!-- Example Row 2 -->
       

        <!-- Add more rows as needed -->
    </tbody>
</table>
<script>
function openView(idl,did) {

    var url = `ViewDiesal.php?Application_id=${idl}&did=${did}`;
    var screenWidth = window.screen.width;
    var screenHeight = window.screen.height;
    var windowWidth = Math.round(screenWidth * 0.5); // 50% width
    var windowHeight = Math.round(screenHeight * 0.5); // Aspect ratio maintained

    var left = Math.round((screenWidth - windowWidth) / 2);
    var top = Math.round((screenHeight - windowHeight) / 2);
    var features = "resizable=yes,width=" + windowWidth + ",height=" + windowHeight + ",left=" + left + ",top=" + top;

    var newWindow = window.open(url, "_blank", features);

    newWindow.focus();
}
</script>
</body>
</html>
