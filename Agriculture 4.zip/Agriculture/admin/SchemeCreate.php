<?php include 'admindashboard.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stylish Form</title>
<style>
    .form-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width:25%;
        position:absolute;
        left:50%;
        top:10%;
    }
    .form-group {
        margin-bottom: 20px;
    }
    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }
    input[type="text"],
    input[type="date"],
    select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>
    
<div class="form-container">
    <h2>Government Scheme Form</h2>
    <form action="" method="post">
        <div class="form-group">
            <label for="schemeType">Scheme Type</label>
            <select id="schemeType" name="schemeType" required>
                <option value="">Select Scheme Type</option>
                <option value="central">Central</option>
                <option value="state">State</option>
            </select>
        </div>
        <div class="form-group">
            <label for="eligibleArea">Eligible Area</label>
            <input type="text" id="eligibleArea" name="eligibleArea" required>
        </div>
        <div class="form-group">
            <label for="schemeName">Scheme Name</label>
            <input type="text" id="schemeName" name="schemeName" required>
        </div>
        <div class="form-group">
            <label for="startDate">Start Date</label>
            <input type="date" id="startDate" name="startDate" required>
        </div>
        <div class="form-group">
            <label for="endDate">End Date</label>
            <input type="date" id="endDate" name="endDate" required>
        </div>
        <div class="form-group">
            <label for="link">Link</label>
            <input type="text" id="link" name="link" required>
        </div>
        <input type="submit" value="Submit" name='save'>
    </form>
    <?php
    if(isset($_POST['save'])){
      $ssql="insert into Schemes(Scheme_Type,Eligible_Area,Scheme_Name,Link,start,end) values('$_POST[schemeType]','$_POST[eligibleArea]','$_POST[schemeName]','$_POST[link]','$_POST[startDate]','$_POST[endDate]');";
      if(mysqli_query($conn,$ssql)){
        echo "New Scheme Link Created";
      }else{
        echo mysqli_error($conn);
      }
    }
    ?>
</div>
</body>
</html>
