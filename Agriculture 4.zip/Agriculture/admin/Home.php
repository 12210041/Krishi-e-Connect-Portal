<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .dash{
            padding:1%;
           margin-left:15%;
            display:grid;
            grid-template-columns:25% 25% 25% 25%;
            grid-template-areas:'d1 d2 d3 d4'
                                'd6 d5 d5 d5' ;
                                gap:1%;
            justify-content:center;
            grid-template-rows:20vh auto;
        }
        .dash div{
            border-radius:20px;
            text-align:center;
            padding:10%;
            font-size:20px;
            color:white;
            font-weight:600;
        }
        .dash div:nth-child(1){
            background-color:#ff00ff;
            grid-area:d1;
            
        }
        .dash div:nth-child(2){
            background-color:#945EFF;
            grid-area:d2;
        }
        .dash div:nth-child(3){
            background-color:#FFA8B2;
            grid-area:d3;
        }
        .dash div:nth-child(4){
            background-color:#00A2FF;
            grid-area:d4;
        }
        .dash div:nth-child(5){
            background-color:#daedf0;
            grid-area:d5;
            color:black;
            box-shadow:3px 4px 1px black;
            padding:2%;
            position:relative;
        }
        .dash div:nth-child(6){
            background-color:#daedf0;
            grid-area:d6;
            color:black;
            padding:2%;
        }
        * {
        box-sizing: border-box;
    }
    .gmail-inbox-table {
        width: 100%;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
    }
    .gmail-inbox-table th {
        background-color: #f2f2f2;
        text-align: left;
        padding: 10px;
    }
    .gmail-inbox-table td {
        border-bottom: 1px solid gray;
        padding: 10px;
    }
    .gmail-inbox-table input[type="checkbox"] {
        margin-right: 15px;
    }
    .gmail-inbox-table tr:hover{
        box-shadow:10px 7px 4px #daddf0;
        /* background-color:#dbfdf0; */
        cursor:pointer;
    }
    #showmessage{
        position: absolute;
        width:100%;
        top:5%;
        left:0;
        height:auto;
        background-color:white;
        border:2px solid black;
        padding:2%;
        color:black;
        text-align:left;
        transition:2s;
    }
    .close-icon{
        color:red;
        float:right;
        font-size:30px;
        cursor:pointer;
    }
    .i-profie{
        width:80px;
        height:80px;
        border-radius:50%;
        border:2px solid green;
        overflow:hidden;
    } 
  
    #myTextarea::before {
    content: 'Reply';
    color: black;
}
@media (max-width:800px) {

     .dash{
           margin:0%;
            grid-template-columns:50% 50%;
            grid-template-areas:'d1 d2' 
                                'd3 d4'
                                'd5 d5' 
                                ;
            grid-template-rows:20vh auto;
            
        }
        .dash div p{
            font-size:20px;
            font-weight:400;
        }
        #showmessage{
            width:100%;
            margin:0;

        }
}
   
    </style>
</head>
<body>
<?php
include 'officialHeader.php';

?>
<div class="dash">
    <div>
        <p>Registration</p>
        <p><?php echo $n ?></p>
    </div>
    <div>
        <p>Scheme Released</p>
        <p>100</p>
    </div>
    <div>
        <p>Received Application</p>
        <p>8</p>
    </div>
    <div>
    <p>Approved Application</p>
        <p>8</p>
    </div>
    <div>
    <table class="gmail-inbox-table">
    <tbody>
        <?php
        $Qsql="select * from Query where receiver_id=$data[d_id] order by q_id desc";
        $Qres=mysqli_query($conn,$Qsql);
        while($Qdata=mysqli_fetch_assoc($Qres))
        { $d="$Qdata[q_id]";
            $f="Yes";
            if($Qdata['Reply']==null){
                $f="No";
            }
            echo "
            <tr onclick=openmessage('$d')>
            <td><input type=checkbox></td>
            <td>$Qdata[sender_id]</td>
            <td>$Qdata[subject]</td>
            <td>$Qdata[QDate]</td>
            <td>$f</td>
        </tr>";
       
        }
        ?>
        
       
        <!-- Add more rows here -->
    </tbody>
</table>
<?php
if(isset($_GET['idq'])){
    $sql10="SELECT q.*,f.* FROM Query q INNER JOIN farmer_reg f ON CONCAT(f.state, f.farmerid) = q.sender_id WHERE q.q_id =$_GET[idq]";
    $res10=mysqli_query($conn,$sql10);
    $D=mysqli_fetch_assoc($res10);    
    echo "
    <div id='showmessage'>
    <span class='close-icon' onclick=window.location='Home.php'>&times;</span>
    <h1 id='sub'>Subject:$D[subject]</h1>
        <figure class='i-profie'>
      <img src=$D[photo] alt='Description of the image' width='100%' height='100%'>
    </figure>
    <i>From:- $D[sender_id] ($D[f_name] $D[l_name])- $D[QDate]</i>
    <hr>
    <p>$D[sms]</p>
    <form action='' method='post'>
    <label>Reply:</label>
    <input type=text id='myTextarea' name='replysms' ></input>
    <button type=submit name=replysent>Send</button>
    </form>
        </div>";
        if(isset($_POST['replysent'])){
            $sl="UPDATE Query SET reply ='$_POST[replysms]' WHERE q_id = $_GET[idq];";
            if(mysqli_query($conn,$sl)){
                echo "reply success";
            }else{
                echo "sumthing went wrong!";
            }
        }
}

?>

    </div>
    <div>h</div>
</div>
<script>
    function openmessage(q){
        window.location=`Home.php?idq=${q}`;
    //     document.querySelector('#sub').innerText=`${q}`;
    //    document.querySelector('#showmessage').style.display="block";
    }
    </script>
</body>
</html>