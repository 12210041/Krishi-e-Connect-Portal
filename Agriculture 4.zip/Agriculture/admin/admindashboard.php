<?php
session_start();
include 'verifylogin.php';
$d=$_SESSION['officialusr'];
include '../includes/dbConnection.php';
$sql="select * from Department where mob='$d';";
$res=mysqli_query($conn,$sql);
$data=mysqli_fetch_assoc($res);
?>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="../css/admin.css">

<body>

<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:25%">
  <h3 class="w3-bar-item">Menu</h3>
  <a href="admindashboard.php" class="w3-bar-item w3-button">Home</a>
  <a href="#" class="w3-bar-item w3-button">Farmer Details</a>
  <a href="staffRegistration.php" class="w3-bar-item w3-button">Staff Allocation</a>
  <a href="#" class="w3-bar-item w3-button">Staff Details</a>
  <a href="SchemeCreate.php" class="w3-bar-item w3-button">Release Scheme</a>
  <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
</div>
<!-- Page Content -->
<div style="margin-left:25%">

<div class="w3-container w3-teal ">
<h1>Welcome to Official Portal of <?php echo $data['Role'].'('.$data['Name'].')';?></h1>
</div>

</div>

<script src="../JS/jquery.js"></script>
<script>
    $(document).ready(function() {
        
    });
</script>
 
    
</body>
