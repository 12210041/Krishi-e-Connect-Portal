<?php
include 'officialheader.php';
?>
<style>
    .announcement{
        width:40%;
        left:40%;
        position: absolute;
        top:20%;
        border:2px solid green;
        padding:2%;
        border-radius:20px;
        background-color:#E3F8FF;
        font-weight:600;
    }
    @media (max-width:800px) {
      .announcement{
        width:90%;
        left:5%;
        top:30%;
      }
    }
    </style>
<div class="announcement text-dark">
<div class="alert alert-danger text-center" role="alert">
  New Announcement
</div>
<form action="" method="post">
  <div class="form-group">
    <label for="exampleFormControlSelect1">Send To</label>
    <select class="form-control" id="exampleFormControlSelect1" name="sentid">
      <?php
     echo "<option value=$data[area]>All Farmer-$data[area]</option>";

      if($area=='india'){
        $sql="select * from farmer_reg";
      }else
      {
        $sql="select farmerid,state from farmer_reg where block='$area' or dist='$area' or state='$area'";
      }
      $res=mysqli_query($conn,$sql);
      while($r=mysqli_fetch_assoc($res)){
        echo  "<option value=$r[state]$r[farmerid]>$r[state]$r[farmerid]</option>";
      }
      ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Announcement Message</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="sms"></textarea>
  </div>
  <button type="submit" class="btn btn-success" name="submit">Sent</button>
</form>
<?php
if(isset($_POST['submit'])){
    $sql="insert into Announcement(sender_id,receiver_id,sms) values($data[d_id],'$_POST[sentid]','$_POST[sms]')";
    if(mysqli_query($conn,$sql))
    {
    echo "<div class='alert bg-success text-light w-50 float-right rounded ' role=alert>Announcement Sent to $_POST[sentid]
        <span class='material-symbols-outlined'>task_alt</span>
        </div>";
    }else{
        echo "<div class='alert bg-danger text-light w-50 float-right rounded ' role=alert>Something went worng!!
        <span class='material-symbols-outlined'>task_alt</span>
        </div>";
        echo mysqli_error($conn);
    }
   
}
?>
</div>
