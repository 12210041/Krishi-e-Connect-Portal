<?php
include '../includes/dbConnection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data Table</title>
<style>

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;

    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
        font-weight:700;
    }
    th {
        background-color: #FFF2A2;
      
    }
    .view-button {
        background-color: #1CEF50;
        color: white;
        padding: 6px 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-button:hover {
        background-color: #45a049;
    }
    @media screen and (max-width: 768px) {
        /* For smaller screens, display table cells as block */
        th, td {
            display: block;
            width: 100%;
        }
        /* Hide the table headers */
        th {
            display: none;
        }
        /* Adjust button size for smaller screens */
        .view-button {
            padding: 8px 12px;
        }
    }
    form {
        background-color: #fff;
        max-width: 100%;
        margin: 0 auto;
        padding: 0 2% 5% 2%;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }
    select, input[type="text"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 16px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    select {
        background-color: #f9f9f9;
    }
    input[type="text"] {
        background-color: #fff;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float:right;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>



<table>

    <tbody>
        <?php
        if(isset($_GET['Application_id'])){
        $qs="select * from Diesal INNER JOIN Schemes on Diesal.Scheme_id=Schemes.Scheme_id INNER JOIN farmer_reg on Diesal.Farmerid=concat(farmer_reg.state,farmer_reg.farmerid) where App_id=$_GET[Application_id]";
        $res=mysqli_query($conn,$qs);
        $data=mysqli_fetch_assoc($res);
        }
        
        echo "
        <tr>
            <th>Application Id</th>
            <td>$_GET[Application_id]</td>
            <th>Scheme ID</th>
            <td>$data[Scheme_id]</td>
            <th>Farmer ID</th>
            <td>$data[state]$data[farmerid]</td>
            <th>Apply Date</th>
            <td>$data[App_date]</td>
        </tr>
        <tr>
            <th>Farmer name</th>
            <td>$data[f_name] $data[l_name]</td>
            <th>S/O or W/O</th>
            <td>$data[guardian]</td>
            <th>Farming Range</th>
            <td>$data[farmer_range]</td>
            <th>Farmer Type</th>
            <td>$data[farmer_type]</td>
        </tr>
        <tr>
            <th>DOB</th>
            <td>$data[dob]</td>
            <th>Gender</th>
            <td>$data[sex]</td>
            <th>Category</th>
            <td>$data[cotegory]</td>
            <th>State</th>
            <td>$data[state]</td>
        </tr>
        <tr>
            <th>Dist.</th>
            <td>$data[dist]</td>
            <th>Block</th>
            <td>$data[block]</td>
            <th>Location</th>
            <td>$data[village]</td>
            <th>Aadhaar No.</th>
            <td>$data[uidai]</td>
        </tr>
        <tr>
            <th>Contact No.</th>
            <td>$data[mob]</td>
            <th>Email id.</th>
            <td>$data[email]</td>
            <th>Bank Name</th>
            <td>$data[bank]</td>
            <th>IFSC Code</th>
            <td>$data[ifsc]</td>
        </tr>
        <tr>
            <th>Account No.</th>
            <td>$data[ac]</td>
            <th>Registration Date</th>
            <td>$data[reg_date]</td>
            <th>Scheme_Type</th>
            <td>$data[Scheme_Type]</td>
            <th>Scheme Start</th>
            <td>$data[start]</td>
        </tr>
        <tr>
            <th>Khata</th>
            <td>$data[Khata]</td>
            <th>Khesra</th>
            <td>$data[Khesra]</td>
            <th>Claim Price</th>
            <td>$data[Price]</td>
            <th>Diesal Quantity</th>
            <td>$data[Quantity]</td>
        </tr>
        <tr>
            <th>Deisal Invoice</th>
            <td>$data[Invoice_no]</td>
            <th>Irregation Month</th>
            <td>$data[Irrigation_Month]</td>
            <th>Land Receipt</th>
            <td>Type A</td>
            <th>Diesal Receipt</th>
            <td>1</td>
        </tr>
        "?>
       
    </tbody>
 
</table>
<form action="" method="post">
    <label for="status">Update Status:</label>
    <select id="status" name="status">
        <option value="Approve">Approve</option>
        <option value="In Progress">In Progress</option>
        <option value="Rejected">Rejected</option>
    </select>
    <label for="remark">Remark:</label>
    <input type="text" id="remark" name="remark">
    <input type="submit" value="Submit" name='Submit'>
</form>
        <?php
            if(isset($_POST['Submit'])){
                $sql1="insert into UpdateStatus(App_id,status,Remark,d_id) values($data[App_id],'$_POST[status]','$_POST[remark]',$_GET[did])";
                if(mysqli_query($conn,$sql1)){
                    echo "Status Updated";
                }else{
                    echo mysqli_error($conn);
                }
            }
        ?>
</body>
</html>
