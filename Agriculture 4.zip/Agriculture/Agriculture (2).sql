-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2023 at 04:31 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Agriculture`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(2) NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(10) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `pass`) VALUES
(1, 'suraj', 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(3) NOT NULL,
  `bank_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `bank_name`) VALUES
(21, 'AXIS BANK'),
(15, 'BANK OF BARODA'),
(16, 'CENTRAL BANK OF INDIA'),
(17, 'FEDERAL BANK'),
(20, 'HDFC BANK'),
(13, 'ICICI BANK'),
(23, 'IDBI BANK'),
(18, 'INDIAN BANK'),
(22, 'INDUSIND BANK'),
(1, 'PNB-PUNJAB NATIONAL BANK'),
(14, 'SBI'),
(19, 'UNION BANK');

-- --------------------------------------------------------

--
-- Table structure for table `beej`
--

CREATE TABLE `beej` (
  `id` int(4) NOT NULL,
  `scheme` varchar(200) NOT NULL,
  `des` varchar(200) NOT NULL,
  `phasal` varchar(40) NOT NULL,
  `rate` int(4) NOT NULL,
  `anudanper` int(4) DEFAULT NULL,
  `anudankg` int(4) DEFAULT NULL,
  `limitation` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `beej`
--

INSERT INTO `beej` (`id`, `scheme`, `des`, `phasal`, `rate`, `anudanper`, `anudankg`, `limitation`) VALUES
(1, 'राज्य योजना', 'मुख्यमंत्री तीव्र बीज विस्तार योजना	', 'गेहूँ', 43, 0, 36, 20),
(2, 'राष्ट्रिय खाद्य सुरक्षा मिशन गेंहू', 'जीरो टिलेज (गेंहू) प्रत्यक्षण', 'गेहूँ', 42, 0, 40, 40),
(3, 'राष्ट्रिय खाद्य सुरक्षा मिशन दलहन', 'प्रत्यक्षण', 'मसूर', 134, 0, 129, 16),
(4, 'राष्ट्रिय खाद्य सुरक्षा मिशन -तेलहन', 'State Plan Oilseeds(Subsidised Seed Distribution)', 'सरसों', 113, 0, 90, 2);

-- --------------------------------------------------------

--
-- Table structure for table `beejapply`
--

CREATE TABLE `beejapply` (
  `b_id` int(4) NOT NULL,
  `farmer_reg` varchar(20) NOT NULL,
  `scheme` varchar(200) NOT NULL,
  `des` int(200) NOT NULL,
  `rate` int(4) NOT NULL,
  `rs` int(4) NOT NULL,
  `anudan` int(4) DEFAULT NULL,
  `total_amount` int(4) NOT NULL,
  `applydate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE `block` (
  `block_id` int(3) NOT NULL,
  `dist_id` int(3) NOT NULL,
  `block_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `block`
--

INSERT INTO `block` (`block_id`, `dist_id`, `block_name`) VALUES
(1, 1, 'BASANTPUR'),
(2, 1, 'BHAGWANPUR HAT'),
(3, 1, 'GORIAKOTHI'),
(4, 1, 'LAKRI NABIGANJ'),
(5, 1, 'MAHARAJGANJ'),
(6, 1, 'DARAUNDHA'),
(7, 1, 'ANDAR'),
(8, 1, 'BARHARIA'),
(9, 1, 'DARAULI'),
(10, 1, 'GUTHANI'),
(11, 1, 'HASAN PURA'),
(12, 1, 'HUSSAINGANJ'),
(13, 1, 'MAIRWA'),
(14, 1, 'NAUTAN'),
(15, 1, 'PACHRUKHI'),
(16, 1, 'RAGHUNATHPUR'),
(17, 1, 'SIWAN SADAR'),
(18, 1, 'SISWAN'),
(19, 1, 'RAGHUNATHPUR');

-- --------------------------------------------------------

--
-- Table structure for table `diesel`
--

CREATE TABLE `diesel` (
  `d_id` int(5) NOT NULL,
  `rs` int(6) NOT NULL,
  `invoice` varchar(50) NOT NULL,
  `khata` varchar(10) NOT NULL,
  `sarve` varchar(30) NOT NULL,
  `rakwa` int(5) NOT NULL,
  `applydate` datetime DEFAULT current_timestamp(),
  `farmer_reg` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diesel`
--

INSERT INTO `diesel` (`d_id`, `rs`, `invoice`, `khata`, `sarve`, `rakwa`, `applydate`, `farmer_reg`, `status`) VALUES
(5, 1, '6', '5', '6', 7, '2023-10-15 02:08:16', 'R2022-2318', 'Rejected'),
(6, 89, '9', '98', '989', 888, '2023-10-15 02:30:37', 'R2022-2317', 'Rejected'),
(7, 200, '8788', '7767', '877,8989', 100, '2023-10-17 10:09:12', 'R2022-2320', 'Processing'),
(8, 10000, '12,13,432', '34', '32,34,12', 100, '2023-10-18 09:53:29', 'R2022-2335', 'Approved'),
(9, 77, '2', '656', '56', 5, '2023-10-19 00:26:46', 'R2022-2333', 'Approved'),
(11, 7, 'hhh', '7', '77', 6, '2023-10-19 00:28:13', 'R2022-2334', 'Process'),
(13, 89, '34', '34', '4', 4, '2023-10-19 00:28:50', 'R2022-2336', 'Approved'),
(14, 3000, '5,5,5,5', '32', '44,44,65', 100, '2023-10-20 10:56:59', 'R2022-2338', 'Rejected'),
(15, 2000, '65656', '45', '767', 100, '2023-10-20 15:12:11', 'R2022-2339', 'Rejected'),
(16, 4545, '565,555,787', '10', '7', 100, '2023-11-12 11:21:06', 'R2022-2340', 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `dist`
--

CREATE TABLE `dist` (
  `state_id` int(3) NOT NULL,
  `dist_id` int(3) NOT NULL,
  `Dist_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dist`
--

INSERT INTO `dist` (`state_id`, `dist_id`, `Dist_Name`) VALUES
(5, 1, 'Siwan'),
(5, 2, 'Saran'),
(5, 3, 'Madhepura'),
(5, 4, 'Araria'),
(5, 5, ' Arwal'),
(5, 6, 'Aurangabad(BH)'),
(5, 7, 'Banka '),
(5, 8, 'Begusarai'),
(5, 9, 'Bhagalpur'),
(5, 10, 'Bhojpur'),
(5, 11, 'Buxar'),
(5, 12, ' Darbhanga '),
(5, 13, 'Gaya '),
(5, 14, 'Gopalganj '),
(5, 15, 'Jamui '),
(5, 16, 'Jehanabad '),
(5, 17, 'Kaimur (Bhabua)'),
(5, 18, 'Katihar'),
(5, 19, ' Khagaria'),
(5, 20, ' Kishanganj '),
(5, 21, 'Lakhisarai'),
(5, 22, 'Madhepura'),
(5, 23, 'Madhubani'),
(5, 24, 'Munger '),
(5, 25, 'Muzaffarpur');

-- --------------------------------------------------------

--
-- Table structure for table `farmer_reg`
--

CREATE TABLE `farmer_reg` (
  `farmerid` int(10) NOT NULL,
  `session` varchar(8) DEFAULT NULL,
  `farmer_type` varchar(20) DEFAULT NULL,
  `f_name` varchar(30) DEFAULT NULL,
  `l_name` varchar(30) DEFAULT NULL,
  `guardian` varchar(50) DEFAULT NULL,
  `dob` varchar(12) DEFAULT NULL,
  `age` int(2) DEFAULT NULL,
  `sex` varchar(11) DEFAULT NULL,
  `cotegory` varchar(10) DEFAULT NULL,
  `farmer_range` varchar(20) DEFAULT NULL,
  `dist` int(3) DEFAULT NULL,
  `block` int(3) DEFAULT NULL,
  `panchayat` int(3) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `uidai` varchar(20) DEFAULT NULL,
  `bank` int(3) DEFAULT NULL,
  `ifsc` varchar(20) DEFAULT NULL,
  `ac` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mob` varchar(12) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `reg_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmer_reg`
--

INSERT INTO `farmer_reg` (`farmerid`, `session`, `farmer_type`, `f_name`, `l_name`, `guardian`, `dob`, `age`, `sex`, `cotegory`, `farmer_range`, `dist`, `block`, `panchayat`, `village`, `uidai`, `bank`, `ifsc`, `ac`, `email`, `mob`, `photo`, `reg_date`) VALUES
(17, '2022-23', 'रैयत किसान', 'jjhj', 'hjh', 'jjh', '2023-10-10', NULL, 'Female', 'SC', 'mediumFarmer', 1, 2, 1, 'badar jamin', '3379041', 15, 'sdsada', '827102', 'psuraj470@hotmail.com', '09006195930', '../upload_image/hjh', '2023-10-14 14:39:52'),
(18, '2022-23', 'गैर रैयत', 'suraj kumar', 'pandey', 'tilak nand pandey', '2023-10-04', NULL, 'Male', 'SC', 'mediumFarmer', 1, 2, 14, 'badar jamin', '337904124368', 15, '7878', '76767676', 'psuraj470@hotmail.com', '85060000', '../upload_image/pandey12.jpg', '2023-10-14 23:33:44'),
(19, '2022-23', 'गैर रैयत', 'SURAJ', 'KUMAR', 'cz', '2023-10-03', NULL, 'Female', 'OBC', 'mediumFarmer', 1, 2, 2, 'xz', 'zx', 15, 'cz', 'zc', 'psuraj470@hotmail.com', '08507097130', '../upload_image/KUMARprofile.png', '2023-10-15 00:38:14'),
(20, '2022-23', 'रैयत किसान', 'krishna', 'pandey', 'sabita devi', '2023-10-11', NULL, 'Female', 'OBC', 'bigFarmer', 1, 2, 1, 'ggg', '3379041', 15, '7878', '827102', 'psuraj470@hotmail.com', '996655555', '../upload_image/pandey19264327_808546199318740_6627500816173169890_o.jpg', '2023-10-15 02:47:31'),
(21, '2022-23', 'रैयत किसान', 'h', 'hj', 'hj', '2023-10-10', NULL, 'Female', 'SC', 'mediumFarmer', 1, 2, 2, 'kj', 'jkj', 13, 'hjhj', 'jjh', 'psuraj470@hotmail.com', '09006195', '../upload_image/hj19264327_808546199318740_6627500816173169890_o.jpg', '2023-10-15 02:51:04'),
(22, '2022-23', 'गैर रैयत', 'n', 'nb', 'nb', '2023-10-03', NULL, 'Female', 'OBC', 'mediumFarmer', 1, 2, 2, 'n', 'nmn', 15, 'nmn', 'n', 'psuraj470@hotmail.com', '89989898', '../upload_image/nb122210041.key', '2023-10-15 02:53:45'),
(23, '2022-23', 'रैयत किसान', 'h', 'jhh', 'ghg', '2023-10-04', NULL, 'Male', 'OBC', 'mediumFarmer', 1, 2, 2, 'nmnm', '9898', 21, '87778', '787878', 'psuraj470@hotmail.com', '06195930', '../upload_image/jhh122210041.key', '2023-10-15 02:55:31'),
(24, '2022-23', 'गैर रैयत', 'SURAJ', 'KUMAR', 'fgfg', '2023-10-04', NULL, 'Male', 'OBC', 'bigFarmer', 1, 2, 4, 'ggg', '337904124368', 16, 'sda', '827102', 'psuraj470@hotmail.com', '878787878', '../upload_image/KUMARn4.jpg', '2023-10-17 02:00:09'),
(25, '2022-23', 'गैर रैयत', 'SURAJ', 'KUMAR', 'tilak nand pandey', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 2, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmail.com', '5656565656', '../upload_image/KUMARn3.jpg', '2023-10-17 02:03:10'),
(26, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pandeyn', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 3, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5656565658', '../upload_image/KUMARn3.jpg', '2023-10-17 02:04:31'),
(27, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pand776', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 4, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5655668758', '../upload_image/KUMARn3.jpg', '2023-10-17 02:07:52'),
(28, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pand776', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 4, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5655668158', '../upload_image/KUMARn3.jpg', '2023-10-17 02:11:23'),
(29, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pand776', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 2, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5655268158', '../upload_image/KUMARn3.jpg', '2023-10-17 02:12:05'),
(30, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pand776', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 2, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5655761158', '../upload_image/KUMARn3.jpg', '2023-10-17 02:13:20'),
(31, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'tilak nand pand776', '2023-10-03', NULL, 'Other', 'SC', 'bigFarmer', 1, 2, 2, 'ggg', '999999', 15, '7878', '827102', 'psuraj470@hotmhail.com', '5635761158', '../upload_image/KUMARn4.jpg', '2023-10-17 02:15:06'),
(32, '2022-23', 'गैर रैयत', 'akhil', 'dwivedi', 'rajiv ranjan', '2023-10-18', NULL, 'Male', 'General', 'mediumFarmer', 1, 2, 5, 'up', '8998988989', 17, '7878', '76767676', 'akhil@gmail.com', '67667767676', '../upload_image/dwivediWhatsApp Image 2023-10-16 at 2.20.21 PM (1).jpeg', '2023-10-17 12:03:59'),
(33, '2022-23', 'रैयत किसान', 'shivam', 'kumar', 'nan', '2023-10-17', NULL, 'Male', 'OBC', 'mediumFarmer', 1, 2, 2, 'phagwara', '8989898989', 21, 'kid8989', '878787887', 'psuraj470@hotmail.com', '9546747447', '../upload_image/kumarWhatsApp Image 2023-10-16 at 2.20.21 PM.jpeg', '2023-10-18 09:38:42'),
(34, '2022-23', 'रैयत किसान', 'shivam', 'kumar', 'nan', '2023-10-17', NULL, 'Male', 'OBC', 'mediumFarmer', 1, 2, 4, 'phagwara', '8989898989', 21, 'kid8989', '878787887', 'psuraj470@hotmail.com', '9546747448', '../upload_image/kumarWhatsApp Image 2023-10-16 at 2.20.21 PM.jpeg', '2023-10-18 09:39:26'),
(35, '2022-23', 'रैयत किसान', 'sahil', 'kumar', 'ghghgh', '2023-10-26', NULL, 'Male', 'General', 'bigFarmer', 1, 2, 3, 'phagwara', '7878787878', 17, 'gfggfg', '665656', 'psuraj470@hotmail.com', '09909090', '../upload_image/kumarWhatsApp Image 2023-10-16 at 9.26.47 PM.jpeg', '2023-10-18 09:51:36'),
(36, '2022-23', 'गैर रैयत', 'aditya', 'mishra', 'ghhgh', '2023-10-03', NULL, 'Other', 'OBC', 'mediumFarmer', 1, 2, 2, 'hgh', '988', 17, 'cvbvh', 'hgh', 'ghgh@gh.com', '999999999', '../upload_image/mishraIMG_20230127_173224.jpg', '2023-10-18 11:29:38'),
(37, '2022-23', 'रैयत किसान', 'SURAJ', 'KUMAR', 'fgfg', '2023-10-09', NULL, 'Male', 'SC', 'mediumFarmer', 1, 2, 3, 'ggg', '3379041', 15, '7878', '76767676', 'psuraj470@hotmail.com', '9234567890', '../upload_image/KUMAR', '2023-10-20 03:03:07'),
(38, '2022-23', 'गैर रैयत', 'rajan', 'kumar', 'Bharat Prasad', '2000-12-15', NULL, 'Male', 'General', 'mediumFarmer', 1, 2, 6, 'Champara', '988989898989', 21, 'hghghgh', '89878', 'psuraj470@hotmail.com', '8999999999', '../upload_image/kumar', '2023-10-20 10:55:10'),
(39, '2022-23', 'रैयत किसान', 'bhawna', 'sharma', 'hgghh', '2023-10-12', NULL, 'Female', 'General', 'bigFarmer', 1, 2, 3, 'simla', '989889898989', 15, 'ghghg', '87878787', 'bhawna5677@lpu.in', '7878787878', '../upload_image/sharmaScreenshot 2023-10-19 at 2.43.38 PM.png', '2023-10-20 15:10:14'),
(40, '2022-23', 'गैर रैयत', 'kumar', 'yash', 'nbnbnbn', '2023-11-14', NULL, 'Male', 'OBC', 'mediumFarmer', 1, 2, 2, 'ghg', '989889898989', 17, 'ghg', '889898998', 'skp@gmail.com', '6767676767', '../upload_image/yashWhatsApp Image 2023-11-11 at 8.52.45 AM.jpeg', '2023-11-12 11:19:50');

-- --------------------------------------------------------

--
-- Table structure for table `panchayat`
--

CREATE TABLE `panchayat` (
  `p_id` int(5) NOT NULL,
  `block_id` int(3) NOT NULL,
  `panchayat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `panchayat`
--

INSERT INTO `panchayat` (`p_id`, `block_id`, `panchayat`) VALUES
(1, 2, 'MAHAMDA'),
(2, 2, 'SARAIPADAULI'),
(3, 2, 'KHEDWA'),
(4, 2, 'BANSOHI'),
(5, 2, 'BADKAGAON'),
(6, 2, 'BITHUNA'),
(7, 2, ' MORA KHAS'),
(8, 2, ' SHANKARPUR'),
(9, 2, 'MIRJUMLA'),
(10, 2, 'KAUDIA'),
(11, 2, ' BHIKHAMPUR'),
(12, 2, ' BRAHMSTHAN'),
(13, 2, ' SHAARHRAON'),
(14, 2, 'BALAHA  ARAZI '),
(15, 2, 'GOPALPUR'),
(16, 2, ' MAHAMMADPUR'),
(17, 2, ' BILASPUR'),
(18, 2, ' SAGAR SULTANPUR'),
(19, 2, 'MAHAMDA'),
(20, 2, 'SARAIPADAULI');

-- --------------------------------------------------------

--
-- Table structure for table `States`
--

CREATE TABLE `States` (
  `state_id` int(3) NOT NULL,
  `state_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `States`
--

INSERT INTO `States` (`state_id`, `state_name`) VALUES
(1, 'Andaman & Nicobar Is'),
(2, 'Andaman & Nicobar Is'),
(3, 'Andhra Pradesh'),
(4, 'Arunachal Pradesh'),
(5, 'Assam'),
(6, 'Bihar'),
(7, 'Chandigarh'),
(8, 'Dadra & Nagar Haveli'),
(9, 'Delhi'),
(10, 'Goa, Daman & Diu'),
(11, 'Gujarat'),
(12, 'Haryana'),
(13, 'Himachal Pradesh	'),
(14, 'Jammu & Kashmir	'),
(15, 'Himachal Pradesh	'),
(16, 'Jammu & Kashmir'),
(17, 'JKerala'),
(18, 'Lakshadweep'),
(19, 'Madhya Pradesh'),
(20, 'Maharashtra'),
(21, 'Manipur'),
(22, 'Tripura'),
(23, 'Karnataka (Mysore)'),
(24, 'Nagaland'),
(25, 'Orissa'),
(26, 'Pondicherry'),
(27, 'Punjab'),
(28, 'Rajasthan'),
(29, 'Tamil Nadu'),
(30, 'Tripura'),
(31, 'Uttar Pradesh(UP)'),
(32, 'West Bengal'),
(33, 'Sikkim'),
(34, 'Mizoram');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD UNIQUE KEY `bank_name` (`bank_name`);

--
-- Indexes for table `beej`
--
ALTER TABLE `beej`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`anudankg`);

--
-- Indexes for table `beejapply`
--
ALTER TABLE `beejapply`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `block`
--
ALTER TABLE `block`
  ADD PRIMARY KEY (`block_id`);

--
-- Indexes for table `diesel`
--
ALTER TABLE `diesel`
  ADD PRIMARY KEY (`d_id`),
  ADD UNIQUE KEY `farmer_reg` (`farmer_reg`);

--
-- Indexes for table `dist`
--
ALTER TABLE `dist`
  ADD PRIMARY KEY (`dist_id`);

--
-- Indexes for table `farmer_reg`
--
ALTER TABLE `farmer_reg`
  ADD PRIMARY KEY (`farmerid`),
  ADD UNIQUE KEY `mob` (`mob`);

--
-- Indexes for table `panchayat`
--
ALTER TABLE `panchayat`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `States`
--
ALTER TABLE `States`
  ADD PRIMARY KEY (`state_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `beej`
--
ALTER TABLE `beej`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beejapply`
--
ALTER TABLE `beejapply`
  MODIFY `b_id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `block`
--
ALTER TABLE `block`
  MODIFY `block_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `diesel`
--
ALTER TABLE `diesel`
  MODIFY `d_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `dist`
--
ALTER TABLE `dist`
  MODIFY `dist_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `farmer_reg`
--
ALTER TABLE `farmer_reg`
  MODIFY `farmerid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `panchayat`
--
ALTER TABLE `panchayat`
  MODIFY `p_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `States`
--
ALTER TABLE `States`
  MODIFY `state_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
