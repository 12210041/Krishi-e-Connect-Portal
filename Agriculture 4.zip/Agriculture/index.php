<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Krishi E-connect</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="style.css">
    <style>


    @import url("https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:wght@100;900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,300;1,900&display=swap");
:root {
}
html {
  scroll-behavior: smooth;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-size: 40px;
  font-family: "Roboto", sans-serif;
  font-weight: 400;
  font-style: normal;
}
.main-header {
  padding: .5% 0.5% 0.5% 0.5%;
  display: flex;
  width: 100%;
  justify-content: space-around;
  position: absolute;
  z-index:100;
}
.navbar {
  display: flex;
  list-style: none;
  align-items: center;
}
.navbar li {
  margin-left: 0.5rem;
}
.navbar li a {
  font-size: 0.4rem;
  text-decoration: none;
  color: rgb(255, 255, 255);
  position: relative;
}
.navbar li a:hover {
  color: rgb(55, 113, 208);
}
.navbar li a::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: 0;
  width: 0;
  height: 2px;
  background-color: rgb(55, 113, 208);
  transition: .3s;
}
.navbar li a:hover::after {
  width: 100%;
}
.navbar li span {
  color: rgb(239, 233, 233);
}
.logo {
  display: flex;
  width: 5%;
 background-color: white;
 padding: 5px;
}
.home {
  width: 100%;
  height: 95vh;
  animation: change-image 20s infinite;
  /* opacity: .8; */
  position: relative;
  z-index: 90;
}
#search_i{
  position: absolute;
  width:50%;
  background-color: white;
  padding: 1%;
  z-index: 100;
  top:25%;
  left:25%;
  transition: 2s;
  border-radius: 100px;
  display: none;
  justify-content: space-around;
  align-items: center;
}
#search_i input{
  width:80%;
  border-radius: 100px;
  z-index: inherit;
  border:2px solid rgb(0, 200, 255);
}#search_i .cl{border:2px solid rgb(0, 200, 255);border-radius: 40%;display: flex;}
#search_i .cl span{
  color:brown;
  font-size: 40px;
  font-weight: 900;
}
#search_i .cl:hover span{
  transform: rotate(300deg);
  cursor: pointer;
}
.sidebar{
  background-color: rgb(37, 34, 34);
  width:30%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index:1;
}
.shadow-home {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  z-index:0;
  /* filter: blur(2px); */
  background-color: rgba(0, 0, 0, 0.523);
  /* background: linear-gradient(to top left, transparent 10%, rgb(0, 0, 0)) */
}

@keyframes change-image {
  0% {
    background: url("./image/f1.jpeg");
    background-size: cover;
    background-size: 100%;
  }
  33% {
    background: url("./image/f2.jpeg");
    background-size: cover;
    background-size: 100%;
  }
 66% {
    background: url("./image/f3.jpeg");
    background-size: cover;
    background-size: 100%;
  }
  100% {
    background: url("./image/f4.jpeg");
    background-size: cover;
  }
}
.home-content {
  position: absolute;
  top: 35%;
  left: 10%;
  width: 50%;
  z-index: 92;
}
.home-content p:nth-child(1) {
  color: white;
  font-size: 0.5rem;
  font-weight: 200;
  line-height: 100%;
}
.home-content p:nth-child(2) {
  color: white;
  font-size: 1.5rem;
  font-weight: 300;
  line-height: 100%;
}
.list {
  position: absolute;
  display: grid;
  width: 100%;
  padding: 1%;
  grid-template-columns: 20% 20% 20% 20%;
  justify-content: center;
  left: 0;
  bottom: 0;
  gap: 1%;
}
.list .item {
  align-items: center;
}
.list .item p {
  font-size: 0.3rem;
  color: rgb(255, 252, 252);
  font-weight: 500;
  position: relative;
  text-align: center;
  padding: 10px;
}
.list .item p::after {
  content: "";
  position: absolute;
  bottom: 0;
  left: 20%;
  background: linear-gradient(to top left, rgb(9, 237, 240), rgb(46, 87, 190));
  height: 0.16rem;
  width: 80%;
  border-radius: 10px;
  z-index:98;
}
.second {
  height: 100vh;
  width: 100%;
  padding: 5%;
  background-color: rgb(232, 229, 229);
  position: relative;
}
.second p:nth-child(1) {
  font-weight: 300;
  font-size: 0.6rem;
  margin-bottom: 10px;
  line-height: 100%;
}
.second p {
  width: 50%;
  padding-left: 10%;
  font-weight: 200;
  font-size: 0.6rem;
  color:black
}
.secont-slider {
  display: grid;
  margin: 3%;
  grid-template-columns: 22% 22% 22% 22%;
  gap: 1%;
  justify-content: center;
  align-items: center;
}
.secont-slider .pic1 {
  position: relative;
  z-index: 2;
  height: 50vh;
}

.bluring {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  filter: blur(5px);
  z-index: 3;
  background-color: rgba(17, 16, 16, 0.406);
  color: white;
}
.secont-slider .pic1:hover .bluring {
  height: 0%;
  transition: ease-in 0.5s;
  cursor: pointer;
}
.secont-slider .pic1 .pic1-content {
  position: absolute;
  color: white;
  left: 1%;
  top: 2%;
  z-index: 10;
  width: 100%;
}
.secont-slider .pic1 .arrow {
  position: absolute;
  color: white;
  right: 2%;
  bottom: 2%;
  z-index: 11;
}
.secont-slider .pic1 .arrow span {
  font-size: 1.3rem;
  font-weight: 100;
}
.secont-slider .pic1-content p {
  width: 90%;
  color:white;
}
.secont-slider .pic1 img {
  border-radius: 10px;
  overflow: hidden;
}

@media (max-width:768px) {
  .second{
    height: auto;
  }
  .secont-slider {
    grid-template-columns: 44% 44%;
    background-color: white;
    padding: 4%;
    border-radius: 30px;
  }
  .secont-slider .pic1 {
    position: relative;
    z-index: 2;
    height: 40vh;
  }
  .second p{
    width: 80%;
  }
  .third-slider div{
    width: auto;
  }
  .forth {
    height: auto;
    width: 100%;
    margin-left: 0;
    grid-template-areas:
      "col1 col2"
      "col4 col4"
      "col3 col5";
  }
  .sixth{
    grid-template-areas: 'ar1  ar2'
                          'ar3 ar4' 
                          'ar5 ar6';
    grid-template-columns: 40% 40%;
    justify-content: center;
    grid-template-rows: 10vh 50vh 50vh;
    padding: 2% 0%;
    height: auto;
}
.navbar{
  display: none;
}
}
</style>
</head>
<body>
   <header class="main-header">
                <ul class="navbar">
                    <li onclick="document.getElementById('search_i').style.display='flex'"><span class="material-symbols-outlined"> search</span></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="./User/login_index.php">Login</a></li>
                    <li><a href="./User/Registration.php">Registration</a></li>
                    <li><a href="#">News</a></li>
                    <li><a href="./admin/login.php">Official Login</a></li>
                </ul>
                <div class="seperator"></div>
        <div class="logo">
            <img src="./image/e-krishi.png" alt="" width="100%" height="100%">
        </div>
   </header>
   <div class="home">
    
    <div id="search_i"><input type="Search"><div class="cl" onclick="document.getElementById('search_i').style.display='none'"><span class="material-symbols-outlined">
        close</span></div></div>
    <div class="shadow-home"></div>
    <div class="home-content">
        <p>E-Krishi Connect</p>
        <P>Aapki Kheti, Aage Badhe.</P>
        <p style="color:rgb(113, 114, 113)">" हर भारतवासी के थाल में बिहार का एक व्यंजन हो "</p>
    </div>
    <div class="list">
        <div class="item">
            <p>Scheme Announced</p>
        </div>
        <div class="item">
            <p>Total Farmer</p>
        </div>
        <div class="item">
            <p>Total Benificiary</p>
        </div>
        <div class="item">
            <p>Upcomming Schemes</p>
        </div>
    </div>
   </div>
   <div class="second">
        <p>Happy Farmers</p>
        <p>Through e-Krishi Connect, I cultivate not just crops, but a future rooted in transparency and trust.
        </p>
        <div class="secont-slider">
            <div class="pic1">
                <div class="bluring"> </div>
                <div class="pic1-content">
                    <p>SUSTAINABILITY</p>
                    <p>Lorem ipsum dolor sit amet,elit.  </p>
                </div>
                <img src="./image/lbg.webp" alt="" width="100%" height="100%">
                <div class="arrow">
                    <span class="material-symbols-outlined"> arrow_circle_right </span>
                </div>
            </div>
            <div class="pic1">
                <div class="bluring"> </div>
                <div class="pic1-content">
                    <p>SUSTAINABILITY</p>
                    <p>Lorem ipsum dolor sit amet,elit.  </p>
                </div>
                <img src="./image/img2.jpeg" alt=""  width="100%" height="100%">
                <div class="arrow">
                    <span class="material-symbols-outlined"> arrow_circle_right </span>
                </div>
            </div>
            <div class="pic1">
                <div class="bluring"> </div>
                <div class="pic1-content">
                    <p>SUSTAINABILITY</p>
                    <p>Lorem ipsum dolor sit amet,elit.  </p>
                </div>
                <img src="./image/ll.png" alt=""  width="100%" height="100%">
                <div class="arrow">
                    <span class="material-symbols-outlined"> arrow_circle_right </span>
                </div>
            </div>
            <div class="pic1">
                <div class="bluring"> </div>
                <div class="pic1-content">
                    <p>SUSTAINABILITY</p>
                    <p>Lorem ipsum dolor sit amet,elit.  </p>
                </div>
                <img src="./image/MixLogo.png" alt=""  width="100%" height="100%">
                <div class="arrow">
                    <span class="material-symbols-outlined"> arrow_circle_right </span>
                </div>
            </div>
        </div>
   </div>

</body>
</html>