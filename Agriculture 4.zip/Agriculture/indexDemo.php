
<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width,&#32;initial-scale=1" /><title>
	Krishi E-Connect
</title><link href="new_css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" /><link href="new_css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" /><link href="new_css/material.css" rel="stylesheet" type="text/css" media="all" /><link href="new_css/animate.css" rel="stylesheet" type="text/css" media="all" /><link href="new_css/style.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body class="active-preloader-ovh homepage">
<form method="post" action="" id="form1">






    <div class="preloader">
		<div class="spinner"></div>
	</div>
    <header>
        <div class="topheader homeheader">
            <div class="container-fluid">
                <div class="row m-0 justify-content-center">
                    <div class="col-12 col-sm-2 col-md-2">
                        <ul class="hometopmenu">
                                <li>
                                <a href="Contacts.html">Contact Us</a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">Sitemap</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 align-items-center justify-content-center">
                        <ul class="hometopmenu gigwmenu">
                            <li><a href="#MainContent" target="_top" class="hide li_eng responsive_minis_eng">Skip to main content</a></li>
                            <li><a href="ScreenReader.html" class="hide">Screen Reader Access</a></li>
                            <li><a href="https://twitter.com/pmkisanofficial" target="_blank"><svg viewBox="0 0 24 24" aria-hidden="true" class="r-18jsvk2 r-4qtqp9 r-yyyyoo r-16y2uox r-8kz0gk r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-lrsllp"><g><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></g></svg></a></li>
                            <li><a href="https://www.facebook.com/PMKISANofficial/" target="_blank"><i class="fab fa-facebook"></i></a></li>
                            <li><a href="https://www.youtube.com/@pm-kisan/" target="_blank"><i class="fab fa-youtube"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-4 col-md-4">
                        <ul class="hometopmenu rightmenu">
                            <li>
                                <select name="ddlLanguage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ddlLanguage\&#39;,\&#39;\&#39;)&#39;,&#32;0)" id="ddlLanguage" class="form-control">
	<option selected="selected" value="99">English</option>
	<option value="1">Assamese</option>
	<option value="5">Gujarati</option>
	<option value="6">Hindi</option>
	<option value="7">Kannada</option>
	<option value="11">Malayalam</option>
	<option value="13">Marathi</option>
	<option value="20">Tamil</option>
	<option value="21">Telugu</option>
	<option value="22">Urdu</option>

</select>
                            </li>
                            <li>
                                <a href="admin/login.php">Official Login</a>
                            </li>
                            
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="midheader">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-sm-3 col-md-3">
                        <div class="logotext">
                            <div class="logotextinner">
                                <h1>Krish E-Connect</h1>
                                <p>Department of Agriculture and Farmers Welfare</p>
                                <p>Ministry of Agriculture and Farmers Welfare</p>
							    <p>Government of India</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-3 col-md-3 mixlogo text-center">
                        <img src="new_images/MixLogo.png" alt="Logo New" class="img-fluid" />
                    </div>
                    <div class="col-12 col-sm-6 col-md-6">
                        <div class="mainmenuarea">
                            <div class="mainmenu">
                                <nav id="mobile-menu">
                                   <ul>
                                        <li class="nav-item helpline">
                                            <a class="nav-link" href="Contacts.html">
                                                <i class="fa fa-phone-square" aria-hidden="true"></i>
                                                <div class="details">
                                                    <p>PM-Kisan Helpline No.</p>
                                                    <h4>155261 / 011-24300606</h4>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="mobile-menu"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="bannerarea">
        <div id="bannerslider" class="owl-carousel">
            <div class="bannerphoto">
                <img src="new_images/PMkisan_1.jpg" alt="Pradhan Mantri Kisan Samman Nidhi" />
            </div>
            <div class="bannerphoto">
                <img src="new_images/PMkisan_2.jpg" alt="Pradhan Mantri Kisan Samman Nidhi" />
            </div>
            
			
        </div>
        <div class="quickaction">
            <ul>
                <li class="text-center">
                    <a href="User/Registration.php">
                        <span class="mdi mdi-cash-register"></span>
                        <span class="newtitle">New Farmer Registration</span>
                    </a>
                </li>
                <li class="text-center">
                    <a href="User/login_index.php">
                        <span class="mdi mdi-account-badge-horizontal-outline"></span>
                        <span class="newtitle">Login</span>
                    </a>
                </li>
                <li class="text-center">
                    <a href="">
                        <span class="mdi mdi-account-group"></span>
                        <span class="newtitle">Know Your Status</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="formercorner">
        <div class="container-fluid">
            <div class="formercornercontent text-center">
                <p><a href="https://pmindiawebcast.nic.in/" target="_blank">Honourable Prime Minister will release the 16th Installment of PM KISAN scheme on 28th February 2024.</a></p>
                <p><a>PM-Kisan Helpline No. 155261 / 011-24300606</a></p>
                <p>eKYC is MANDATORY for PMKISAN Registered Farmers. OTP Based eKYC is available on PMKISAN Portal</p>
		        <p>or nearest CSC centres may be contacted for Biometric based eKYC.</p>
            </div>
            <div class="periodwisepayment">
				
				<div class="headingtext">Period Wise Payments</div>
				<ul id="periodwise" class="owl-carousel">

                     <li id="Li1" class="border-righr">
                        <span id="Trim2024_2" class="mb-0">9,07,50,086</span>
                        <span class="beni-month">AUG-NOV 2023-24</span>
                    </li>

                    <li id="trim14" class="border-righr">
                        <span id="Trim2024_1" class="mb-0">9,60,05,019</span>
                        <span class="beni-month">APR-JUL 2023-24</span>
                    </li>

		            <li id="trim13" class="border-righr">
                    <span id="Trim2023_3" class="mb-0">8,82,24,184</span>
                    <span   class="beni-month">DEC-MAR 2022-23</span>
                    </li>

                    <li id="trim12" class="border-righr">
                    <span id="Trim2023_2" class="mb-0">9,01,73,669</span>
                    <span   class="beni-month">AUG-NOV 2022-23</span>
                    </li>
                    <li id="trim11" class="border-righr">
                    <span id="Trim2023_1" class="&#32;mb-0">11,29,71,186</span>
                    <span   class="beni-month">APR-JUL 2022-23</span>
                    </li>
                    <li id="trim10" class="border-righr">
                    <span id="Trim2022_3" class="&#32;mb-0">11,16,87,744</span>
                    <span   class="beni-month">DEC-MAR 2021-22</span>
                    </li>
                    <li id="trim9" class="border-righr">
                    <span id="Trim2022_2" class="&#32;mb-0">11,19,67,102</span>
                    <span   class="beni-month">AUG-NOV 2021-22</span>
                    </li>
                    <li id="trim8" class="border-righr">
                    <span id="Trim2022_1" class="mb-0">11,19,93,686</span>
                    <span  class="beni-month">APR-JUL 2021-22</span> 
                    </li>
                    <li id="trim7" class="border-righr">
                    <span id="Trim2021_3" class="mb-0">10,23,62,300</span>
                    <span  class="beni-month">DEC-MAR 2020-21</span> 
                    </li>
                    <li id="trim6" class="border-righr">
                    <span id="Trim2021_2" class="mb-0">10,23,48,546</span>
                    <span  class="beni-month">AUG-NOV 2020-21</span> 
                    </li>
                    <li id="trim5" class="border-righr">
                    <span id="Trim2021_1" class="mb-0">10,49,42,966</span>
                    <span  class="beni-month">APR-JUL 2020-21</span> 
                    </li>
                    <li id="trim4" class="border-righr">
                    <span id="Trim1920_3" class="&#32;mb-0">8,97,04,764</span>
                    <span  class="beni-month">DEC-MAR 2019-20</span> 
                    </li>
                    <li id="trim3" class="border-righr">
                    <span id="Trim1920_2" class="mb-0">8,76,33,664</span>
                    <span  class="beni-month">AUG-NOV 2019-20</span> 
                    </li>
                    <li id="trim2" class="border-righr">
                    <span id="Trim1920_1" class="mb-0">6,63,58,518</span>
                    <span  class="beni-month">APR-JUL 2019-20</span> 
                    </li>
                    <li id="trim1" class="border-righr">
                    <span id="Trim1819_3" class="mb-0">3,16,16,998</span>
                    <span  class="beni-month">DEC-MAR 2018-19</span> 
                    </li>
                </ul>
            </div>
        </div>
    </div>
<script src="new_js/jquery-3.6.3.min.js"></script>
<script src="new_js/popper.min.js"></script>
<script src="new_js/bootstrap.min.js"></script>
<script src="new_js/owl.carousel.min.js"></script>
<script src="new_js/jquery.meanmenu.min.js"></script>
<script src="new_js/custom.js"></script>




</form>
</body>

<!-- Mirrored from pmkisan.gov.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Mar 2024 05:06:07 GMT -->
</html>