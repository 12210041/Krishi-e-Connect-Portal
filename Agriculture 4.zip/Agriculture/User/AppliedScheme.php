<?php
include 'header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application List</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
    }
    table {
        position: relative;
        width: 100%;
        margin-left:0%;
        border-collapse: collapse;
    }
    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    .view-button {
        background-color: #4CAF50;
        color: white;
        padding: 8px 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-button:hover {
        background-color: #45a049;
    }
    .popup-container {
        position: fixed;
        top: 50%;
        left: 50%;
        z-index: 100;
        transform: translate(-50%, -50%);
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .popup-message{
        border-bottom:2px solid blue;
    }
    .popup-message p{
        font-size: 18px;
        color: #322 ;
        line-height:100%;
        margin-bottom:0px;
    }
    .popup-button {
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 10px 20px;
        cursor: pointer;
    }
    .popup-button:hover {
        background-color: #45a049;
    }
    i{
        color:orange;
    }
</style>
</head>
<body>
    <center><h1>Application List</h1></center>
    <hr> <hr> <hr>
<table>
    <thead>
        <tr>
            <th>Application No</th>
            <th>Scheme Name</th>
            <th>Scheme Type</th>
            <th>Application Date</th>
            <th>View Details</th>
        </tr>
    </thead>
    <tbody>
        <!-- Example Row 1 -->
        <?php
        
            $qs="select * from Diesal INNER JOIN Schemes on Diesal.Scheme_id=Schemes.Scheme_id where Farmerid='$userid'";
        $resp=mysqli_query($conn,$qs);
        while($dt=mysqli_fetch_assoc($resp)){
            echo "
            <tr>
            <td>$dt[App_id]</td>
            <td>$dt[Scheme_Name]</td>
            <td>$dt[Scheme_Type]</td>
            <td>$dt[App_date]</td>
            <td><button class='view-button' onclick='showStatus($dt[App_id])'>View App</button></td>
        </tr>
            ";
        }
        ?>
    </tbody>
    <?php
    if(isset($_GET['Appid'])){
        $ss="select * from UpdateStatus INNER JOIN Department on UpdateStatus.d_id=Department.d_id where App_id=$_GET[Appid]";
        $r=mysqli_query($conn,$ss);
        ?>
        <div class='popup-container' id='popupContainer'>
            <?php
        while($dy=mysqli_fetch_assoc($r)){
            echo"
            
        <div class='popup-message' id='appid'>
        <p>Status:$dy[status]</p>
        <p>Remark:$dy[Remark]</p>
      <i>By:-$dy[Role]-$dy[Name] &nbsp; $dy[update_date]<i>
        </div>
     
            ";}?>
            <button class='popup-button' onclick='closePopup()'>Close</button>
         </div>
         <?php
        
    }
    
    ?>
    
</table>
<script>
function showStatus(vv){
    window.location=`AppliedScheme.php?Appid=${vv}`;
}
function closePopup() {
    var popupContainer = document.getElementById("popupContainer");
    popupContainer.style.display = "none";
}
</script>
</body>
</html>
