<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .container {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    .icon {
        color: #4CAF50;
        font-size: 50px;
        margin-bottom: 20px;
    }

    .message {
        font-size: 20px;
        margin-bottom: 20px;
    }

    .button {
        background-color: #007bff;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        font-size: 16px;
        transition: background-color 0.3s;
    }

    .button:hover {
        background-color: #0056b3;
    }
    </style>
</head>

<body>
    <?php
include '../includes/dbConnection.php';
$farmerType=$_POST['farmerType'];
$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];
$guardian=$_POST['guardian']; 
$dob=$_POST['dob'];
$sex=$_POST['sex'];
$category=$_POST['category'];
$farmerRange=$_POST['farmerRange'];
$state=$_POST['state']; 
$dist=$_POST['dist'];
$block=$_POST['block'];
$village=$_POST['village']; 
$uidai=$_POST['uidai']; 
$email=$_POST['email'];
$mobile=$_POST['mobile']; 
$bank=$_POST['bank']; 
$Branch=$_POST['Branch'];
$ifsc=$_POST['ifsc']; 
$ac=$_POST['ac']; 
$Password=$_POST['Password'];
$cPassword=$_POST['cPassword'];
$password=$_POST['pass'];
$img="not";
?>
    
        <?php
if(isset($_FILES['photo']))
        {
            $tmpfile=$_FILES['photo']['tmp_name'];
            $filename=$_FILES['photo']['name'];
            if(move_uploaded_file($tmpfile,"../upload_image/".$lname.$filename));
            $img="../upload_image/".$lname.$filename;
        }
        $count=0;
        $sql3="select mob from farmer_reg where mob='$mobile'";
        $res=mysqli_query($conn,$sql3);
        $count=mysqli_num_rows($res);
        if($count>0)
        {
            echo "Mobile number is already registered";
        } else
        {
$sql="insert into farmer_reg(farmer_type,f_name,l_name,guardian,dob,sex,
cotegory,farmer_range,state,dist,block,village,
uidai,bank,ifsc,ac,email,mob,password,photo) values('$farmerType','$firstName','$lastName','$guardian',
'$dob','$sex','$category','$farmerRange','$state',
'$dist','$block','$village','$uidai','$bank',
'$ifsc','$ac','$email','$mobile','$Password',
'$img');";
if(!mysqli_query($conn,$sql))
{
//    $error=mysqli_error($conn);
//    print("Error Occurred: ".$error);
    echo "Registration faild".mysqli_error($conn);
}else
{
    $regi=mysqli_insert_id($conn);
    echo "
    <div class='registration_details'>
    <div class='container'>
        <div class='icon'><i class='fas fa-check-circle'></i></div>
        <div class='message'>Registration Successful!</div>
        <p id='regno'>Your Registration No:$state$regi and Password :$Password</p>
        <a href='../index.php' class='button'>Login</a>
    </div>
    ";
   
   
}
        }
?>

</body>

</html>