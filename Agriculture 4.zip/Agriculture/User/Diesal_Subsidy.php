<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stylish Form</title>
<style>
    .form-container {
        width:100%;
        height:auto;
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        background-color: #fff;
        padding: 5%;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .form-container form{display:grid;
        grid-template-columns:50% 50%;
        gap:2%;
        justify-content:center;
        align-items:center;
    }
    .form-group {
        margin-bottom: 20px;
    }
    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }
    input[type="text"],
    input[type="number"],
    input[type="file"],
    select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-left:20%;
    }
    input[type="reset"] {
        background-color: maroon;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-left:20%;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    input[type="reset"]:hover {
        background-color: red;
    }
</style>
</head>
<body>
<div class="form-container">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="landAcNo">Land Account Number</label>
            <input type="text" id="landAcNo" name="landAcNo" required>
        </div>
        <div class="form-group">
            <label for="sarveNo">Survey Number</label>
            <input type="text" id="sarveNo" name="sarveNo" required>
        </div>
        <div class="form-group">
            <label for="dieselLtr">Diesel Liters</label>
            <input type="number" id="dieselLtr" name="dieselLtr" required>
        </div>
        <div class="form-group">
            <label for="purchagePrice">Purchase Price</label>
            <input type="number" id="purchagePrice" name="purchagePrice" required>
        </div>
        <div class="form-group">
            <label for="irrigationMonth">Irrigation Month</label>
            <input type="text" id="irrigationMonth" name="irrigationMonth" required>
        </div>
        <div class="form-group">
            <label for="invoiceNumber">Invoice Number</label>
            <input type="text" id="invoiceNumber" name="invoiceNumber" required>
        </div>

        <div class="form-group">
            <label for="landReceipt">Land Receipt</label>
            <input type="file" id="irrigationImage" name="irrigationImage" multiple accept="image/*" required>
        </div>
        <div class="form-group">
            <label for="invoiceImage">Invoice Image</label>
            <input type="file" id="invoiceImage" name="invoiceImage" accept="image/*" required>
        </div>
        <input type="submit" value="Submit" name="savef">
        <input type="reset" value="reset">
    </form>
    <?php
    if(isset($_POST['savef'])){
        $slq="insert into Diesal(Scheme_id,Farmerid,Khata,Khesra,Price,Quantity,Irrigation_Month,Invoice_no) values($_GET[Scheme_id],'$_GET[farmerid]','$_POST[landAcNo]',
        '$_POST[sarveNo]',$_POST[purchagePrice],$_POST[dieselLtr],'$_POST[irrigationMonth]','$_POST[invoiceNumber]')";
        if(mysqli_query($conn,$slq)){
            ?>
            <script>
                alert("Schemed Applied Successfully");
                window.close();
                </script>
            <?php
        }else
        {
            echo mysqli_error($conn);
        }
        
    }
    ?>
</div>
</body>
</html>
