<?php
include '../includes/dbConnection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registration Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f4;
  }

  #registrationForm {
    width: 400px;
    background-color: #fff;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
  }

  .step,.step3 {
    display: none;
  }

  h2 {
    margin-top: 0;
  }

  label {
    display: block;
    margin-bottom: 8px;
  }

  input[type="text"],
  input[type="email"],
  input[type="tel"],
  input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  select {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  button {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
  }

  button:hover {
    background-color: #0056b3;
  }

  .buttons {
    margin-top: 20px;
  }

  .buttons button:first-child {
    margin-right: 10px;
  }
  input[type="date"] {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-color: white;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type="date"]::-webkit-calendar-picker-indicator {
    display: none;
  }

  input[type="date"]::-webkit-inner-spin-button,
  input[type="date"]::-webkit-clear-button {
    display: none;
  }

  input[type="date"]::-webkit-datetime-edit-text {
    color: #333;
  }

  input[type="date"]::-webkit-datetime-edit-month-field {
    color: #333;
  }

  input[type="date"]::-webkit-datetime-edit-day-field {
    color: #333;
  }

  input[type="date"]::-webkit-datetime-edit-year-field {
    color: #333;
  }
  @media (max-width: 480px) {
    #registrationForm {
      width: 90%;
    }
  }
</style>
</head>
<body>

<form id="registrationForm" action="registration_process.php" method="post" enctype="multipart/form-data">
  <div class="step1" id="step1">
    <h2> Personal Information</h2>

    <label for="farmerType">Farmer Type:</label>
    <select id="farmerType" name="farmerType">
      <option value="self">Self</option>
      <option value="Rented">Rented/Lease</option>
    </select>
    
    <label for="firstName">First Name:</label>
    <input type="text" id="firstName" name="firstName">
    
    <label for="lastName">Last Name:</label>
    <input type="text" id="lastName" name="lastName">
    
    <label for="guardian">Guardian:</label>
    <input type="text" id="guardian" name="guardian">
    
    <label for="dob">Date of Birth:</label>
    <input type="date" id="dob" name="dob">
    
    <label for="sex">Sex:</label>
    <select id="sex" name="sex">
      <option value="male">Male</option>
      <option value="female">Female</option>
      <option value="other">Other</option>
    </select>
    
    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="General">General</option>
        <option value="OBC">OBC</option>
        <option value="SC">SC</option>
        <option value="ST">ST</option>
        <option value="EBC">EBC</option>
      </select>
    
    <label for="farmerRange">Farmer Range:</label>
    <select id="farmerRange" name="farmerRange">
        <option value="Small">Small Farmer</option>
        <option value="Medium">Medium</option>
        <option value="Big">Big Farmer</option>
      </select>
    <div class="buttons">
      <button type="button" onclick="nextStep('step1', 'step2')">Next</button>
      <a  href="../index.php">Back</a>
    </div>
  </div>

  <div class="step" id="step2">
    <h2>Location and Contact Details</h2>
    <label for="state">State:</label>
    <select name="state" id="state">
        <option value="select">Select</option>
      </select>
    
    <label for="dist">District:</label>
    <select  name="dist" id="dist">
        <option value="select">Select</option>
      </select>
    
    <label for="block">Block:</label>
    <input type="text" id="block" name="block">
    
    <label for="village">Village:</label>
    <input type="text" id="village" name="village">
    
    <label for="uidai">UIDAI:</label>
    <input type="text" id="uidai" name="uidai">

    <label for="email">Email Id:</label>
    <input type="email" id="email" name="email">
    
    <label for="Mobile">Mobile:</label>
    <input type="text" id="mobile" name="mobile">
    
    <div class="buttons">
      <button type="button" onclick="prevStep('step2', 'step1')">Previous</button>
      <button type="button" onclick="nextStep('step2', 'step3')">Next</button>
    </div>
  </div>
  <div class="step3" id="step3">
    <h2>Additional Information </h2>
    <label for="bank">Bank Name</label>
    <input type="text" id="bank" name="bank">
    
    <label for="Branch">Branch Name:</label>
    <input type="text" id="Branch" name="Branch">
    
    <label for="ifsc">IFSC Code:</label>
    <input type="text" id="ifsc" name="ifsc">

    <label for="ac">Account Number:</label>
    <input type="text" id="ac" name="ac">
    
    <label for="Password">Password:</label>
    <input type="password" id="Password" name="Password">
    
    <label for="cPassword">Confirm Password:</label>
    <input type="password" id="cPassword" name="cPassword">
    
    <label for="photo">Photo:</label>
    <input type="file" id="photo" name="photo">
 
    <div class="buttons">
      <button type="button" onclick="prevStep('step3', 'step2')">Previous</button>
      <button type="submit">Submit</button>
    </div>
  </div>
</form>
<script src="../Js/jquery.js"></script>
<script>

  function nextStep(currentStep, nextStep) {
    document.getElementById(currentStep).style.display = 'none';
    document.getElementById(nextStep).style.display = 'block';
  }

  function prevStep(currentStep, prevStep) {
    document.getElementById(currentStep).style.display = 'none';
    document.getElementById(prevStep).style.display = 'block';
  }
  // state api

  $('#state').on('click',function(){
        var headers = new Headers();
        headers.append("X-CSCAPI-KEY", "RWVhcnI3M2dMRTJsSGswOHM0aU9URGl3SjN4S2U4WHA2alpFM0QxMg==");
        var requestOptions = {
        method: 'GET',
        headers: headers,
        redirect: 'follow'
        };
        fetch("https://api.countrystatecity.in/v1/countries/IN/states", requestOptions)
        .then(response => response.json())
        .then(result =>{
            $('#state').append(result.map((data)=>`<option value="${data.name}">${data.name}-${data.iso2}</option>`))
         })
        .catch(error => console.log('error', error));
    })

    // dist api
    $('#state').on('change',function(){
        let x=$('#state').find('option:selected').text();
        const state=x.substring(x.length-2,x.length);
        var headers = new Headers();
        headers.append("X-CSCAPI-KEY", "RWVhcnI3M2dMRTJsSGswOHM0aU9URGl3SjN4S2U4WHA2alpFM0QxMg==");
        var requestOptions = {
        method: 'GET',
        headers: headers,
        redirect: 'follow'
        };
        fetch(`https://api.countrystatecity.in/v1/countries/IN/states/${state}/cities`, requestOptions)
        .then(response => response.json())
        .then(result =>{
            $('#dist').append(result.map((data)=>`<option value=${data.name}>${data.name}</option>`))
         })
        .catch(error => console.log('error', error));
        
    })
</script>

</body>
</html>
