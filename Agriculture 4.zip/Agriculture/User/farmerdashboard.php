<?php
include 'header.php';
?>
        <div class="Fdetails">
            <div class="profile">
                <img src=<?php echo $data['photo'] ?> alt="" width="90%">
                <p><?php echo $data['f_name']." ".$data['l_name'] ?></p>
            </div>
            <table class="detailsTable">
                <tr>
                    <td>Reg No</td>
                    <td><?php echo $userid?></td>
                    <td>Farmer Type</td>
                    <td><?php echo $data['farmer_type']?></td>

                </tr>
                <tr>
                    <td>S/O or W/O</td>
                    <td><?php echo $data['guardian']?></td>
                    <td>Gender</td>
                    <td><?php echo $data['sex']?></td>
                </tr>
                <tr>
                    <td>Date of Birth</td>
                    <td><?php echo $data['dob']?></td>
                    <td>Category</td>
                    <td><?php echo $data['cotegory']?></td>
                </tr>
                <tr>
                    <td>Farmer range</td>
                    <td><?php echo $data['farmer_range']?></td>
                    <td>State</td>
                    <td><?php echo $data['state']?></td>
                </tr>
                <tr>
                    <td>Dist.</td>
                    <td><?php echo $data['dist']?></td>
                    <td>Block</td>
                    <td><?php echo $data['block']?></td>
                </tr>
                <tr>
                    <td>Location</td>
                    <td><?php echo $data['village']?></td>
                    <td>Aadhar No.</td>
                    <td><?php echo $data['uidai']?></td>
                </tr>
                <tr>
                    <td>Email id</td>
                    <td><?php echo $data['email']?></td>
                    <td>Mobile No.</td>
                    <td><?php echo $data['mob']?></td>
                </tr>
                <tr>
                    <td>Bank Name</td>
                    <td><?php echo $data['bank']?></td>
                    <td>IFSC Code</td>
                    <td><?php echo $data['ifsc']?></td>
                </tr>
                <tr>
                    <td>Account No.</td>
                    <td><?php echo $data['ac']?></td>
                    <td>Registration Date</td>
                    <td><?php echo $data['reg_date']?></td>
                </tr>
            </table>
        </div>
        <div class="heading">
            <p class="text-light">Allocated Authorities</p>
        </div>
        <section style="height: 20vh;overflow:scroll" id="#Officer">
            <table class="officerTable">
                <tr style="background-color:pink;">
                    <th>Role</th>
                    <th>Name</th>
                    <th>RaiseQuery</th>
                    <th>Seating Plan</th>
                </tr>
                <?php
            $sql1="select * from Department where area='$data[state]' OR area='$data[dist]' OR area='$data[block]' OR area='india' OR area='technical'";
            $res1=mysqli_query($conn,$sql1);
            while($r=mysqli_fetch_assoc($res1)){
                $nm=$r["Name"];
                echo "
                <tr>
                <td>$r[Role]</td>
                <td>$r[Name]</td>
                <td><a href='#' onclick=handleClick($r[d_id],'$r[Role]')>Raise Query<a></td>
                <td>$r[Office]</td>
            </tr>
                ";
            }
            ?>
            </table>
        </section>
        <hr>
        <div class="heading" id="Announcement">
            <p class="text-light"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor"
                    class="bi bi-messenger" viewBox="0 0 16 16">
                    <path
                        d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.64.64 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.64.64 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76m5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z" />
                </svg> Announcement</p>
        </div>
        <section style="max-height: 30vh;overflow:scroll;">
            <?php
    $sql4="select * from Announcement INNER JOIN Department on Announcement.sender_id=Department.d_id where receiver_id='india' or receiver_id='$$data[state]' or receiver_id='$userid' or receiver_id='$data[block]' ORDER BY an_id DESC;";
    $res4=mysqli_query($conn,$sql4);
    while($a_data=mysqli_fetch_assoc($res4)){
        echo "
        <div class=sms>
        <p >$a_data[sms]</p>
        <i>$a_data[Name] ( $a_data[Role] )</i>
        <i>$a_data[senttime]</i>
        </div>
        ";
    }
    ?>
        </section>
        <div class="heading">
            <p class="text-light">New Scheme</p>
        </div>
        <section style="max-height: 50vh;overflow:scroll" id='schemeinfo'>
            <table class="officerTable">
                <tr>
                    <th>Government</th>
                    <th>Scheme Name</th>
                    <th>Eligible Area</th>
                    <th>Start</th>
                    <th>Closed</th>
                    <th>Status</th>
                    <th>Registere</th>
                    <th><a href="">About Scheme</a></th>
                </tr>
                <?php
                $ssql="select * from Schemes where Eligible_Area='india' or Eligible_Area='$data[state]' or Eligible_Area='$data[dist]' or Eligible_Area='$data[block]' order by Scheme_id desc";
                $response=mysqli_query($conn,$ssql);
                while($srow=mysqli_fetch_assoc($response)){
                    $currentDate = (date('Y-m-d') > $srow['end']) ? "Closed": "Open";
                    $link=($currentDate=='Closed')? "#" : "$srow[Link]?Scheme_id=$srow[Scheme_id]&farmerid=$userid";
                    // $link=($currentDate<=$srow['start'])?  $srow['Link'] : "#" ;
                    // if($srow['start']>$srow['start'])
                    echo "
                    <tr>
                    <td>$srow[Scheme_Type]</td>
                    <td>$srow[Scheme_Name]</td>
                    <td>$srow[Eligible_Area]</td>
                    <td>$srow[start]</td>
                    <td>$srow[end]</td>
                    <td>$currentDate</td>
                    <th><a  href=''  class='btn btn-warning' onclick=window.open('$link','_blank','resizable=yes,width=screen.availWidth')>Registered</a></th>
                    <th><a href=>About Scheme</a></th>
                </tr>
                    ";
                }
                ?>
                
            </table>
        </section>
        <div class="bg-secondary heading p-1 m-2">
            <i>&copy;SKumar Pandey</i>
        </div>
        <!-- query popup -->
        <div id="query">
            <center><span class="material-symbols-outlined">sms Log Query</span></center>
            <p id="close"><span class="material-symbols-outlined">cancel</span></p>
            <form action="" id='instruct' onsubmit="return false">
                <p id="to"></p>
                <div class="checkbox-circle">
                    <input type="checkbox" id="term1" name="terms[]" value="term1" checked>
                    <label for="term1"></label>
                    <span> I am responsible for the content typed in query.</span>
                </div>
                <div class="checkbox-circle">
                    <input type="checkbox" id="term2" name="terms[]" value="term2" checked>
                    <label for="term2"></label>
                    <span>The information given by me regarding the complaint/request is true to the best of my
                        knowledge and if found false/ wrong, necessary disciplinary action can be initiated against
                        me.</span>
                </div>
                <div class="checkbox-circle">
                    <input type="checkbox" id="term3" name="terms[]" value="term3" checked>
                    <label for="term3"></label>
                    <span>I understand that necessary disciplinary action can be initiated against me in case of use of
                        derogatory words or false statements against any Student/Faculty/Staff/Higher Authority..</span>
                </div>
                <button type="button" class="button" id='proceed'>Proceed and Agree</button>
            </form>
        </div>
        <!-- auery form -->
        <div>

            <form class="query-form" action="#" method="post" id="query-form">
                <center><span class="material-symbols-outlined">sms Log Query</span></center>
                <p id="Fclose"><span class="material-symbols-outlined">cancel</span></p>
                <div>
                    <label for="from">From:</label>
                    <input type="text" id="from" name="from" class="query-form-input" value='<?php echo $userid ?>' readonly>
                </div>
                <div>
                    <label for="to">To:</label>
                    <input type="text" id="tosend" name="tosend" class="query-form-input" readonly>
                </div>
                <div>
                    <label for="subject">Subject:</label>
                    <input type="text" id="subject" name="subject" class="query-form-input" placeholder="Subject">
                </div>
                <div>
                    <label for="messageBody">Message Body:</label>
                    <textarea id="messageBody" name="messageBody" class="query-form-input" rows="4"
                        placeholder="Your message..."></textarea>
                </div>
                <button type="submit" class="query-form-button" name='submit'>Submit</button>
            </form>
            <?php
            if(isset($_POST['submit'])){
                    $sqlQ="insert into Query(sender_id,receiver_id,subject,sms) values('$_POST[from]','$_POST[tosend]','$_POST[subject]','$_POST[messageBody]');";
                    if(mysqli_query($conn,$sqlQ)){
                        echo '
                        <div id="success-alert">
    Your request has been successfully submitted.
    <span class="close-button" onclick="this.parentElement.style.display="none";"></span>
</div>';
                    }else{
                        echo '
                        <div id="success-alert" class="success-alert">
    Your request has been failed please try again after sometime!
    <span class="close-button" onclick=this.parentElement.style.display="none";></span>
</div>';
                    }
            }
        ?>
    <!-- alert success after submit query -->
    
        </div>
        
        <script>
        document.getElementById('close').addEventListener('click', () => {
            document.getElementById('query').style.display = "none";

        });
        document.getElementById('Fclose').addEventListener('click', () => {
            document.getElementById('query-form').style.display = "none";
        });

        function handleClick(vv, vn) {
            document.getElementById('query').style.display = "block";
            document.getElementById('instruct').action = "vv";
            document.getElementById('to').innerText = `Query to ${vv}-${vn}`;
            document.querySelector('#tosend').value=vv;
        }
        document.getElementById('proceed').addEventListener('click', () => {
            document.getElementById('query').style.display = "none";
            document.getElementById('query-form').style.display = "block";
        });
        </script>

</body>

</html>