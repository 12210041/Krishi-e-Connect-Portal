<?php
include 'header.php';
$ssql="select * from Query INNER JOIN Department on Query.receiver_id=Department.d_id where sender_id='$userid' order by q_id desc";
$res=mysqli_query($conn,$ssql);
if(mysqli_num_rows($res)<=0){
    ?>
    <script>
    alert("no Query!");
    window.location="farmerdashboard.php";
   </script>
    <?php
 
}else
{
while($Qdata=mysqli_fetch_assoc($res)){
echo "
<div class='query-box'>
    <div class='query-details'>
        <strong>Query ID:</strong>#$Qdata[q_id]<br>
        <strong>Query Date:</strong>$Qdata[QDate]<br>
        <strong>Recipient:</strong> $Qdata[Name]($Qdata[Role])-$Qdata[area]<br>
        <strong>Subject:</strong> $Qdata[subject]<br>
        <strong>Message:</strong> $Qdata[sms]
    </div>
    <div class='status'>Reply:  $Qdata[Reply]</div>
    <div class='status'>Date:  $Qdata[ReplyDate]</div>
</div>
";
}
}
?>



</body>
</html>
