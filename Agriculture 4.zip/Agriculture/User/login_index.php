<?php
include '../includes/dbConnection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/Agriculture/css/style.css">
  <link rel="stylesheet" href="/Agriculture/css/index.css">
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9"
    crossorigin="anonymous">
  <title>Agriculture Bihar</title>
  <style>
    body{
      background-color: rgba(0, 0, 0, 0.57);
    }
    
    *{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    .farmerlogin{
      width: 40%;
      margin-left: 30%;
      padding:5% 0%;
    }
    .heading{
      font-size: 10px;
      font-weight: 400;
      padding:0% .1%;
      color:white;
      text-align: center;
      margin: 2% 0%;
      background-color:var(--bs-blue);
      
    }
    .main-content-login{
  height:100vh;
  position: relative;
}
    .footer{
      width:98%;
      position: absolute;
      font-size: 10px;
      font-weight: 400;
      bottom:0;
      color:white;
      text-align: center;
      margin:0;
      background-color:var(--bs-blue);
    }
@media (max-width:800px) {
  .farmerlogin{
    width:80%;
    margin:10%;
  }
  
}
  </style>
</head>
<body>
  <div class="container bg-light main-content-login">
  <section class="topArea">
    <div class="logo">
      <img src="/Agriculture/image/farmer_icon.png" alt width="100%" >
      <div>
        <span>Krishi E-Connect</span>
        <i>One Nation One Portal All Farmer</i>
      </div>
    </div>
    <div>
        <img src="/Agriculture/image/MixLogo.png" alt="" width="100%" height="100%" style="border-radius: 10px;">
    </div>
    <div>

    </div>
  </section>
  <div class="heading">
      <p>Farmer Login Portal</p>
  </div>
  <div class="farmerlogin">
  <div class="center">
  <form class="form-signin" method="post">
    <h2 class="form-signin-heading">Sign In</h2>
    <label for="inputEmail" class="sr-only">Registration Number</label>
    <input type="text" id="inputEmail" name="userid" class="form-control" placeholder="Enter Registration Number" required autofocus>
    <label for="inputPassword" class="sr-only">Password</label>
    <input type="password" id="inputPassword" name="Password" class="form-control" placeholder="Password" required>
    <div class="checkbox">
      <label>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit" name='submit'>Sign in</button>
    <a class="btn btn-lg btn-secondary btn-block" href="../index.php"  >Home</a>
  </form>
</div>
    <?php
    if(isset($_POST['submit'])){
      $user=$_POST['userid'];
      $pass=$_POST['Password'];
      $sql="select password from farmer_reg where concat(state,farmerid)='$user'";
      $res=mysqli_query($conn,$sql);
      $data=mysqli_fetch_assoc($res);
      if($data['password']==$pass){
        $_SESSION['username']=$user;
        header("location:../User/farmerdashboard.php");
      }else{
        echo "<i style=color:red>Invalid Credential Please try again!</i>";
      }
    }
    ?>
  </div>
  <div class="footer">
    <p>&copy;Suraj Kumar Pandey</p>
  </div>
  </div>
  
</body>
</html>