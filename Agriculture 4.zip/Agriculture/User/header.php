<?php
include '../includes/dbConnection.php';
session_start();
$userid=$_SESSION['username'];
$sql="select * from farmer_reg where concat(state,farmerid)='$userid'";
$res=mysqli_query($conn,$sql);
$data=mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Agriculture/css/style.css">
    <link rel="stylesheet" href="/Agriculture/css/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
        <link rel="stylesheet"
        href="style_header.css"/>
    <title>Agriculture Bihar</title>
</head>

<body>
    <div class="container-lg bg-light main-content-login">
        <section class="topArea">
            <div class="logo">
                <img src="/Agriculture/image/farmer_icon.png" alt width="100%">
            </div>
            <div>
            <span class="text-light">Krishi E-Connect</span>
                    <i class="text-light">One Nation One Portal All Farmer</i>
            </div>
            <div>
                <img src="/Agriculture/image/MixLogo.png" alt="" width="100%">
                <p><?php echo "$data[f_name] $data[l_name]"?></p>
            </div>
            <div class="mixlogo">
                <img src=<?php echo $data['photo']?> alt="" width="100%" height="100%"
                    style="border-radius: 10px;">
            </div>
            
        </section>
        <div class="navigation">
            <ul>
                <li><a href="farmerdashboard.php">Home</a></li>
                <li class="dropdown-nav"><a href="">Portal Navigation</a>
                    <div class="navigation-content">
                        <ul class="inside-nav" style="display: block;">
                            <li><a href="#">Update Details</a></li>
                            <li><a href="#schemeinfo">Check Scheme Info</a></li>
                            <li><a href="#">Cancel Registration</a></li>
                            <li><a href="#Announcement">Announcement</a></li>
                            <li><a href="#Officer">Officer Details</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="AppliedScheme.php">Scheme Applied</a></li>
                <li><a href="StatusQuery.php">Query Status</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="logout.php">LogOut</a></li>
            </ul>
        </div>